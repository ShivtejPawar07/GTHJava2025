/*Q47. Pooja would like to withdraw X $US from an ATM. The cash machine will only
accept the transaction if X is a multiple of 5, and Pooja's account balance has 
enough cash to perform the withdrawal transaction (including bank charges). For 
each successful withdrawal the bank charges 0.50 $US.
Calculate Pooja's account balance after an attempted transaction.
Input
Positive integer 0 < X <= 2000 - the amount of cash which Pooja wishes to withdraw. Nonnegative number 0<= Y <= 2000 with two digits of precision - Pooja's initial account balance. Output
Output the account balance after the attempted transaction, given as a number with two digits of precision. If there is not enough money in the account to complete the transaction, output the current bank balance.
Example - Successful Transaction Input:
30 120.00
Output:
89.50
Example - Incorrect Withdrawal Amount (not multiple of 5) Input:
42 120.00
Output:
120.00
Example - Insufficient Funds Input:
300 120.00
Output:
120.00
*/
import java.util.*;
class ATM
 {
    public static void main(String x[])
	{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Amount to Withdrawal");
        int X = sc.nextInt();          // Amount to withdraw
		System.out.println("Enter Account Balance");
        double Y = sc.nextDouble();    // Account balance
        
		if((X>0 && X<=2000)&&(Y>0 && Y<=2000))
		{	
        if (X % 5 == 0)
		{
			 Y = Y - X - 0.50;
            System.out.println("Transaction successful.");
            System.out.printf("Remaining Balance: %.2f\n", Y);
           
        } 
		else if (X + 0.50 > Y)
		{
            System.out.println("Insufficient funds for this transaction.");
            System.out.printf("Current Balance: %.2f\n", Y);
        } 
		else //X%5!=0
		{
			 System.out.println("Withdrawal amount must be a multiple of 5.");
            System.out.printf("Current Balance: %.2f\n", Y);
            
        }
		}//if
		else
		{ 
	      System.out.println("Invalid input");
		}	
    }
}

