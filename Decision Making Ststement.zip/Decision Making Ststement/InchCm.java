//conert into inch to cm
import java.util.*;
class Demo{


}