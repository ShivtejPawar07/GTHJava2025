/*Q17. Write a java program to find the maximum between two numbers.*/
import java.util.*;
class Maximum2{
   public static void main(String x[]){
      Scanner sc=new Scanner(System.in);
	  System.out.println("enter the three numbers");
	  int n1=sc.nextInt();
	  int n2=sc.nextInt();
	
	  
	    if(n1>n2){
		System.out.println(n1 +"is maximum numbers");
		}
		else{
		System.out.println(n2 +"is maximum numbers");
		}
	  
	 
   
   }
}