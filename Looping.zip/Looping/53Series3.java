/* Q53. Write a java program to display following series :

                   1  4  9  16  25  36  49  64  81  100*/
import java.util.*;
class Sq{
	public static void main(String x[]){
		Scanner sc=new Scanner(System.in);
		
		
		int i=1;
		while(i<=10){
		System.out.print(i*i+" ");
		i++;
		}
	
	}
}	