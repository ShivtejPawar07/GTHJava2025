/*Q40. Write a java program to find all prime factors of a number.
The prime factors of a number are all the prime numbers that, when multiplied together, result in the original number. A prime number is a whole number greater than 1 that has only two divisors: 1 and the number itself. 
For example:
The prime factors of 12 are 2 and 3, because 2 x 2 x 3 = 12. 
The prime factors of 20 are 2 and 5, because 2 x 2 x 5 = 20. 
The prime factors of 30 are 2, 3, and 5, because 2 x 3 x 5 = 30. 
*/
import java.util.*;
class PFact{
  public static void main(String x[]){
    Scanner sc=new Scanner(System.in);
	System.out.println("Enter a Number");
	int n=sc.nextInt();
	int i=2;
	while(n>=2){
	  if(n%i==0){
	    System.out.println(i);
		n=n/i;
	}else{
	i++;
	}
  }
}
}