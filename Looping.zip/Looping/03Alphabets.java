/*3.Write a C program to print all alphabets from a to z. - using while loop
*/
import java.util.*;
class Alphabets{
  public static void main(String x[]){
  Scanner sc=new Scanner(System.in);
	 char i='a';
	 while(i<='z'){
	  System.out.println(i);
	  i++;
	 }
  }
}